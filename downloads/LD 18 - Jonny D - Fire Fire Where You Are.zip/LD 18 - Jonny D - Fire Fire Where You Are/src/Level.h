#ifndef _LEVEL_H__
#define _LEVEL_H__

#include <list>
#include "Player.h"

using namespace std;

class Level
{
    public:
    
    float playerX, playerY;
	list<Fire> fires;
	list<House> houses;
	const char* terrainFile;
	const char* bgFile;
	const char* missionText;
    
    Level();
    
    void load(GameState* state);
};


bool loadLevel(GameState* state, int num);


































#endif
