#ifndef _EXTRAMATH_H__
#define _EXTRAMATH_H__

#include <cmath>





inline float dist(Boat* A, CannonBall* B)
{
    return sqrt((A->x - B->x)*(A->x - B->x) + (A->y - B->y)*(A->y - B->y));
}

template<typename T, typename U>
inline float dist(T* A, U* B)
{
    return sqrt((A->x - B->x)*(A->x - B->x) + (A->y - B->y)*(A->y - B->y));
}

template<typename T, typename U>
inline float dist2(T* A, U* B)
{
    return (A->x - B->x)*(A->x - B->x) + (A->y - B->y)*(A->y - B->y);
}





#endif
