#ifndef _POINT2D_H__
#define _POINT2D_H__


class Point2D
{
    public:
    float x, y;
    
    Point2D()
        : x(0), y(0)
    {}
    
    Point2D(float x, float y)
        : x(x), y(y)
    {}
    
};



#endif
