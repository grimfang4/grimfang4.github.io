#ifndef _POINT3D_H__
#define _POINT3D_H__


class Point3D
{
    public:
    float x, y, z;
    
    Point3D()
        : x(0), y(0), z(0)
    {}
    
    Point3D(float x, float y, float z)
        : x(x), y(y), z(z)
    {}
    
};



#endif
