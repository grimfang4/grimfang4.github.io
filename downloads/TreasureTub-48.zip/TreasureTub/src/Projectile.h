#ifndef _PROJECTILE_H__
#define _PROJECTILE_H__

#include "SDL.h"
#include "Boat.h"

class CannonBall
{
    public:
    
    Boat* owner;
    float x, y, z;
    float velx, vely, velz;
    SDL_Surface* pic;
    
    CannonBall(Boat* boat);
    
    bool update(float dt);
    void draw(SDL_Surface* screen, float scrollX, float scrollY);
};


class Splash
{
    public:
    float x, y;
    float timer;
    
    Splash(float x, float y);
    virtual ~Splash();
    
    virtual bool update(float dt);
    virtual void draw(SDL_Surface* screen, float scrollX, float scrollY);
};

class Blast : public Splash
{
    public:
    
    Blast(float x, float y);
    virtual ~Blast();
    
    //bool update(float dt);
    virtual void draw(SDL_Surface* screen, float scrollX, float scrollY);
};





#endif
