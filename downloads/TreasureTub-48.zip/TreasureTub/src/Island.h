#ifndef _ISLAND_H__
#define _ISLAND_H__

#include "SDL.h"
class Chest;
#include "Treasure.h"
#include "Boat.h"

class Island
{
    public:
    float x, y, radius;
    SDL_Surface* pic;
    SDL_Surface* fore;
    SDL_Surface* picBroke;
    SDL_Surface* foreBroke;
    int hp;
    Chest* chest;
    
    
    Island(float x, float y);
    
    void draw(SDL_Surface* screen, float scrollX, float scrollY);
    void drawFore(SDL_Surface* screen, float scrollX, float scrollY);
    
    void hit();
};





#endif
