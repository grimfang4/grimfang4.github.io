#ifndef _TREASURE_H__
#define _TREASURE_H__

#include "SDL.h"
#include "Game.h"

class Map;

class Chest
{
    public:
    enum TypeEnum {ISLAND, UNDERWATER, HIDDEN};
    TypeEnum type;
    float x, y;
    
    Map* map;
    int gold;
    bool isOpen;
    SDL_Surface* pic;
    SDL_Surface* picOpen;
    
    Chest();
    void draw(SDL_Surface* screen, float scrollX, float scrollY);
};

class Map
{
    public:
    Chest* target;
    SDL_Surface* pic;
    SDL_Surface* bigpic;
    float x, y;
    
    Map();
    void draw(SDL_Surface* screen, GameState* state);
};








#endif
